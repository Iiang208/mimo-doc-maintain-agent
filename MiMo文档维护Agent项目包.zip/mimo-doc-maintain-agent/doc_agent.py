#!/usr/bin/env python3
import os
import re
from dotenv import load_dotenv
import requests
from github import Github
import tiktoken

# 加载环境变量
load_dotenv()
MIMO_API_KEY = os.getenv("MIMO_API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
REPO_OWNER = os.getenv("REPO_OWNER")
REPO_NAME = os.getenv("REPO_NAME")

# MiMo API 配置（兼容OpenAI格式）
MIMO_API_BASE = "https://api.xiaomimimo.com/v1"
MODEL_NAME = "mimo-v2.5-pro"  # 支持100万长上下文的旗舰模型

# 初始化token计数器
encoder = tiktoken.get_encoding("cl100k_base")

def count_tokens(text: str) -> int:
    """统计文本的token数量"""
    return len(encoder.encode(text))

def get_repo_info(g: Github):
    """拉取GitHub仓库的核心信息：代码、提交、Issue、旧README"""
    repo = g.get_repo(f"{REPO_OWNER}/{REPO_NAME}")
    
    # 1. 获取旧的README文档
    try:
        readme = repo.get_readme()
        old_readme = readme.decoded_content.decode('utf-8')
    except:
        old_readme = "暂无旧版README"
    
    # 2. 获取核心代码文件（优先拉取核心源码，避免过大的依赖文件）
    code_files = []
    contents = repo.get_contents("")
    while contents:
        file_content = contents.pop(0)
        if file_content.type == "dir":
            # 跳过测试、依赖、文档目录，只拉核心代码
            if file_content.name in ['test', 'tests', 'node_modules', 'vendor', 'docs', 'examples']:
                continue
            contents.extend(repo.get_contents(file_content.path))
        else:
            # 只处理常见的源码文件，大小不超过100KB
            if file_content.name.endswith(('.py', '.js', '.ts', '.go', '.java', '.rs', '.c', '.cpp', '.h')) and file_content.size < 100*1024:
                try:
                    content = file_content.decoded_content.decode('utf-8')
                    code_files.append(f"--- 文件: {file_content.path} ---\n{content}")
                except:
                    continue
    
    code_content = "\n\n".join(code_files[:20])  # 最多取前20个核心文件，避免超出上下文
    
    # 3. 获取最近30天的提交记录
    commits = []
    for commit in repo.get_commits(page=1, per_page=30):
        commit_date = commit.commit.author.date
        commits.append(f"- {commit_date.strftime('%Y-%m-%d')}: {commit.commit.message}")
    commit_content = "\n".join(commits)
    
    # 4. 获取最近30天的Issue
    issues = []
    for issue in repo.get_issues(state='all', sort='created', direction='desc'):
        if issue.created_at.year == 2026 and issue.created_at.month >= 4:
            issues.append(f"# {issue.number}: {issue.title}")
    issue_content = "\n".join(issues[:20])  # 取最近20个Issue
    
    return {
        "old_readme": old_readme,
        "code_content": code_content,
        "commit_content": commit_content,
        "issue_content": issue_content
    }

def generate_new_readme(repo_info: dict):
    """调用MiMo API生成更新后的README"""
    # 构建Prompt
    prompt = f"""你是一个专业的开源项目文档维护专家，现在需要你根据提供的项目信息，更新项目的README文档：

## 项目信息
### 1. 项目的旧版README文档
{repo_info['old_readme']}

### 2. 项目的核心代码文件
{repo_info['code_content']}

### 3. 项目最近的提交记录
{repo_info['commit_content']}

### 4. 项目最近的用户Issue
{repo_info['issue_content']}

## 你的任务
请你完成以下工作：
1. 修正旧README中过时的内容，匹配最新的代码和提交
2. 更新API说明、使用教程，确保和最新代码完全一致
3. 整理Issue中的高频问题，添加到README的FAQ部分
4. 添加最近的变更日志，记录最近的版本更新
5. 保持README的原有结构和Markdown风格，不要大幅改动原有格式
6. 不要添加额外的解释，直接输出更新后的完整README内容
"""
    
    input_tokens = count_tokens(prompt)
    print(f"输入Token数量: {input_tokens}")
    
    # 调用MiMo API
    headers = {
        "Authorization": f"Bearer {MIMO_API_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 32768
    }
    
    response = requests.post(
        f"{MIMO_API_BASE}/chat/completions",
        headers=headers,
        json=data
    )
    
    if response.status_code != 200:
        raise Exception(f"API调用失败: {response.text}")
    
    result = response.json()
    new_readme = result['choices'][0]['message']['content']
    output_tokens = result['usage']['completion_tokens']
    
    print(f"输出Token数量: {output_tokens}")
    print(f"本次总消耗Token: {input_tokens + output_tokens}")
    
    return new_readme

def main():
    if not all([MIMO_API_KEY, GITHUB_TOKEN, REPO_OWNER, REPO_NAME]):
        print("请先配置.env文件中的环境变量！")
        return
    
    # 初始化GitHub客户端
    g = Github(GITHUB_TOKEN)
    print("正在拉取仓库信息...")
    repo_info = get_repo_info(g)
    
    print("正在调用MiMo模型生成新文档...")
    new_readme = generate_new_readme(repo_info)
    
    # 保存新的README
    with open("NEW_README.md", "w", encoding='utf-8') as f:
        f.write(new_readme)
    
    print("文档更新完成！新的README已保存为 NEW_README.md")

if __name__ == "__main__":
    main()
